"""Portable retrieval experiment helpers. No repository imports or model training."""
import hashlib
import json
import time
from pathlib import Path

import numpy as np


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load_bundle(folder):
    folder = Path(folder)
    manifest = json.loads((folder / 'bundle-manifest.json').read_text(encoding='utf-8'))
    for name, expected in manifest['files'].items():
        assert sha(folder / name) == expected, f'Изменён файл: {name}'
    tasks = [json.loads(s) for s in (folder / 'tasks.jsonl').read_text(encoding='utf-8').splitlines()]
    config = json.loads((folder / 'config.json').read_text(encoding='utf-8'))
    split = json.loads((folder / 'split.json').read_text(encoding='utf-8'))
    lookup = {r['task_id']: r for r in tasks}
    assert len(tasks) == len(lookup) == 300
    qids, cids = split['query_ids'], split['candidate_ids']
    assert len(qids) == 20 and len(cids) == 280
    assert not set(qids) & set(cids)
    assert set(qids) | set(cids) == set(lookup)
    assert not {lookup[k]['family'] for k in qids} & {lookup[k]['family'] for k in cids}
    assert all(r['condition_text'].strip() and r['steps'] and r['skills'] and r['kes_codes'] for r in tasks)
    return tasks, config, split


def candidate_text(row, enriched=False):
    text = 'Условие: ' + row['condition_text']
    if enriched:
        text += '\n\nДействия решения:\n' + '\n'.join(f'{i}. {s}' for i, s in enumerate(row['steps'], 1))
        text += '\n\nНавыки:\n' + '\n'.join(s['name'] + ': ' + s['description'] for s in row['skills'])
    return text


def prepare_inputs(tasks, split):
    """Only allowlisted text fields enter the model. KES never enters these strings."""
    lookup = {r['task_id']: r for r in tasks}
    return {
        'queries': ['query: ' + lookup[k]['condition_text'] for k in split['query_ids']],
        'plain': ['passage: ' + candidate_text(lookup[k]) for k in split['candidate_ids']],
        'enriched': ['passage: ' + candidate_text(lookup[k], True) for k in split['candidate_ids']],
    }


def token_lengths(tokenizer, texts):
    return [len(v) for v in tokenizer(texts, padding=False, truncation=False,
                                    add_special_tokens=True)['input_ids']]


def encode(tokenizer, model, texts, device, batch_size=8, max_length=512):
    """Attention-mask mean pooling and L2 normalization, per Multilingual E5 card."""
    import torch
    from tqdm.auto import tqdm
    outputs = []
    started = time.perf_counter()
    with torch.inference_mode():
        for start in tqdm(range(0, len(texts), batch_size), desc='Получение эмбеддингов'):
            batch = tokenizer(texts[start:start + batch_size], padding=True, truncation=True,
                              max_length=max_length, return_tensors='pt').to(device)
            hidden = model(**batch).last_hidden_state
            mask = batch['attention_mask'].unsqueeze(-1).bool()
            pooled = hidden.masked_fill(~mask, 0).sum(dim=1) / mask.sum(dim=1)
            vectors = torch.nn.functional.normalize(pooled, p=2, dim=1)
            outputs.append(vectors.cpu().float().numpy())
    result = np.concatenate(outputs)
    assert result.shape == (len(texts), 384) and np.isfinite(result).all()
    assert np.allclose(np.linalg.norm(result, axis=1), 1, atol=1e-5)
    return result, time.perf_counter() - started


def evaluate(scores, tasks, split, variant):
    """P@5, Hit@5, and reciprocal rank over ALL 280 candidates; zero if no positive."""
    lookup = {r['task_id']: r for r in tasks}
    qids, cids = split['query_ids'], split['candidate_ids']
    assert scores.shape == (len(qids), len(cids)) and np.isfinite(scores).all()
    per_query, ranking = [], []
    for i, qid in enumerate(qids):
        q = lookup[qid]
        relevant = np.array([bool(set(q['kes_codes']) & set(lookup[c]['kes_codes'])) for c in cids])
        # Ties are broken by candidate order recorded in split.json.
        order = np.argsort(-scores[i], kind='stable')
        positions = np.flatnonzero(relevant[order])
        rr = 1 / (int(positions[0]) + 1) if len(positions) else 0.0
        per_query.append(dict(variant=variant, query_id=qid, has_images=q['has_images'],
                              positive_candidates=int(relevant.sum()),
                              precision_at_5=float(relevant[order[:5]].mean()),
                              hit_at_5=int(relevant[order[:5]].any()), reciprocal_rank=rr))
        for rank, j in enumerate(order, 1):
            c = lookup[cids[j]]
            ranking.append(dict(variant=variant, query_id=qid, candidate_id=c['task_id'], rank=rank,
                                cosine=float(scores[i, j]), relevant=bool(relevant[j]),
                                shared_kes=' | '.join(sorted(set(q['kes_codes']) & set(c['kes_codes'])))))
    return per_query, ranking
