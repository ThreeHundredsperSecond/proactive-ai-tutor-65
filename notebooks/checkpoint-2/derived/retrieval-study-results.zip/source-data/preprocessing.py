from lxml import html

def clean(text):
    return ' '.join((text or '').replace('\u200b', '').replace('\ufeff', '').split())


def condition_text(source):
    """Render saved MathML to explicit linear math; never naive HTML text flattening."""
    tree = html.fromstring(source)

    def walk(e):
        tag = e.tag.split('}')[-1]
        children = [c for c in e if isinstance(c.tag, str)]
        args = [walk(c) for c in children]
        if tag in ('script', 'style', 'annotation', 'annotation-xml'):
            return ''
        if tag == 'img':
            return ' [Рисунок] '
        if tag in ('br', 'hr'):
            return ' '
        if tag in ('mfrac', 'msup', 'msub', 'mroot', 'mover', 'msubsup'):
            expected = 3 if tag == 'msubsup' else 2
            assert len(args) == expected, (tag, args)
            if tag == 'mfrac': return f'({args[0]})/({args[1]})'
            if tag == 'msup': return f'({args[0]})^({args[1]})'
            if tag == 'msub': return f'({args[0]})_({args[1]})'
            if tag == 'mroot': return f'root({args[1]}; {args[0]})'
            if tag == 'mover': return f'overset({args[1]}; {args[0]})'
            return f'({args[0]})_({args[1]})^({args[2]})'
        if tag == 'msqrt': return 'sqrt(' + ' '.join(args) + ')'
        if tag == 'mfenced':
            separators = ''.join(e.get('separators', ',').split())
            body = args[0] if args else ''
            for i, arg in enumerate(args[1:]):
                body += (separators[min(i, len(separators)-1)] if separators else '') + arg
            return e.get('open', '(') + body + e.get('close', ')')
        if tag == 'mtable': return 'matrix(' + '; '.join(args) + ')'
        if tag == 'mtr': return ', '.join(args)
        if tag == 'sup': return '^(' + ' '.join(args or [clean(e.text)]) + ')'
        if tag == 'sub': return '_(' + ' '.join(args or [clean(e.text)]) + ')'
        if tag.startswith('m') and tag not in ('math', 'mrow', 'mstyle', 'mtext', 'mi', 'mn', 'mo', 'mtd'):
            raise ValueError(f'Неподдержанный MathML: {tag}')
        body = [e.text or '']
        for c in children:
            body.extend([walk(c), c.tail or ''])
        return ' '.join(body)

    return clean(walk(tree))
